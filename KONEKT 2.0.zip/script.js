// ===== USUÁRIOS =====
if(!localStorage.getItem('users')) localStorage.setItem('users', JSON.stringify([]));
let users = JSON.parse(localStorage.getItem('users'));

// Cria admin se não existir
if(!users.some(u=>u.isAdmin)){
users.push({name:'Kleyster',email:'admin@konekt.com',number:'000',password:'123456',isAdmin:true,plan:'Pro',planExpire:null});
localStorage.setItem('users',JSON.stringify(users));
}

// ===== REGISTRO =====
function registerUser(){
const name=document.getElementById('signupName').value.trim();
const email=document.getElementById('signupEmail').value.trim();
const number=document.getElementById('signupNumber').value.trim();
const password=document.getElementById('signupPassword').value.trim();
if(!name||!email||!number||!password){ alert('Preencha todos os campos!'); return; }
if(users.some(u=>u.name===name)){ alert('Usuário já existe!'); return; }
const expire=new Date(new Date().getTime()+3*24*60*60*1000);
users.push({name,email,number,password,isAdmin:false,plan:'Teste Grátis',planExpire:expire.toISOString()});
localStorage.setItem('users',JSON.stringify(users));
alert('Cadastro realizado! 3 dias de teste grátis.');
}

// ===== LOGIN =====
function loginUser(){
const name=document.getElementById('loginName').value.trim();
const password=document.getElementById('loginPassword').value.trim();
const user=users.find(u=>u.name===name && u.password===password);
if(!user){ alert('Usuário ou senha incorretos!'); return; }
localStorage.setItem('currentUser',JSON.stringify(user));
window.location.href='dashboard.html';
}

// ===== DASHBOARD =====
if(window.location.href.includes('dashboard.html')){
let currentUser = JSON.parse(localStorage.getItem('currentUser'));
if(!currentUser){ alert('Faça login!'); window.location.href='index.html'; }

document.querySelector('.greeting').innerText=`Bem-vindo ${currentUser.name}`;
document.getElementById('planDisplay').innerText=currentUser.plan;

// ===== LOGOUT =====
function logout(){ localStorage.removeItem('currentUser'); window.location.href='index.html'; }

// ===== PEDIDOS =====
if(!localStorage.getItem('orders')) localStorage.setItem('orders',JSON.stringify([]));
let orders=JSON.parse(localStorage.getItem('orders'));
const ordersList=document.getElementById('ordersList');

function renderOrders(){
ordersList.innerHTML='';
orders.forEach((order,index)=>{
if(!currentUser.isAdmin && order.name!==currentUser.name) return; 
const card=document.createElement('div'); card.classList.add('order-card');
const info=document.createElement('div'); info.classList.add('order-info');
info.innerHTML=`
<strong>${order.product}</strong><br>
Seu número: ${order.userNumber}<br>
Número do cliente: ${order.clientNumber}<br>
Província: ${order.province}<br>
Data entrega: ${order.deliveryDate}<br>
Status: <span class="status ${order.status}">${order.status}</span>
`;
card.appendChild(info);

// Admin aceita/recusa
if(currentUser.isAdmin){
const acceptBtn=document.createElement('button');
acceptBtn.innerText='Aceitar';
acceptBtn.onclick=()=>{
orders[index].status='entregue';
localStorage.setItem('orders',JSON.stringify(orders));
renderOrders();
};
card.appendChild(acceptBtn);

const rejectBtn=document.createElement('button');
rejectBtn.innerText='Recusar';
rejectBtn.onclick=()=>{
orders[index].status='cancelado';
localStorage.setItem('orders',JSON.stringify(orders));
renderOrders();
};
card.appendChild(rejectBtn);
}
ordersList.appendChild(card);
});
}
renderOrders();

window.createOrderFromInput=()=>{
const product=document.getElementById('productInput').value.trim();
const userNumber=document.getElementById('userNumberInput').value.trim();
const clientNumber=document.getElementById('clientNumberInput').value.trim();
const province=document.getElementById('provinceInput').value.trim();
const deliveryDate=document.getElementById('deliveryDateInput').value;
if(!product||!userNumber||!clientNumber||!province||!deliveryDate){ alert('Preencha todos os campos!'); return; }
orders.push({name:currentUser.name,product,userNumber,clientNumber,province,deliveryDate,status:'pendente'});
localStorage.setItem('orders',JSON.stringify(orders));
renderOrders();
document.getElementById('productInput').value='';
document.getElementById('userNumberInput').value='';
document.getElementById('clientNumberInput').value='';
document.getElementById('provinceInput').value='';
document.getElementById('deliveryDateInput').value='';
};

// ===== ADMIN: Dar PRO =====
if(currentUser.isAdmin){
document.getElementById('adminPanel').style.display='block';
const userSelect=document.getElementById('userSelect');
function refreshUserList(){
userSelect.innerHTML='';
users.forEach(u=>{
if(!u.isAdmin){
const option=document.createElement('option');
option.value=u.name;
option.innerText=u.name;
userSelect.appendChild(option);
}
});
}
refreshUserList();

window.giveProPlan=()=>{
const selectedName=userSelect.value;
const user=users.find(u=>u.name===selectedName);
if(!user) return;
const expire=new Date(new Date().getTime()+30*24*60*60*1000);
user.plan='Pro';
user.planExpire=expire.toISOString();
localStorage.setItem('users',JSON.stringify(users));
alert(`Plano Pro ativado para ${user.name} por 1 mês`);
refreshUserList();

